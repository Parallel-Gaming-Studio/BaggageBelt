INSERT INTO [FlyWithButchOhareDB_Copy].[dbo].[baggagebeltleaderboard] ([user], [score]) VALUES
('XB', 2);