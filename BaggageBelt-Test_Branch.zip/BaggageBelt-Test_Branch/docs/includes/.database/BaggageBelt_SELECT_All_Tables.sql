USE FlyWithButchOhareDB_Copy;

SELECT * FROM baggagebeltleaderboard;