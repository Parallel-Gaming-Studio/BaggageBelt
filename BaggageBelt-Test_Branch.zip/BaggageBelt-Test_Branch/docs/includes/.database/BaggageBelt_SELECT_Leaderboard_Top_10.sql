SELECT TOP (10) [user], [score]
from [FlyWithButchOhareDB_Copy].[dbo].[baggagebeltleaderboard] ORDER BY [score] DESC;